# Tracker (no name)

A light, Apple-Health-style personal tracker. Sunset theme. No login, no server —
your data is stored privately on your own device.

## Screens
- **Today** — type what you did ("gym, prayed, studied"); it logs each as a pill and
  quietly counts it toward a matching goal. Swipe back with the arrows to see past days.
- **Goals** — your 6 long-term goals with progress rings and streaks.
- **To do** — dump your tasks for the week, one per line; tap the circle to check one off and it disappears (Undo pops up for a few seconds).
- **Clear** — brain-dump box to empty your head, plus a one-minute breathing reset.

## Deploy it (same as your other app)
1. Put these files in a GitHub repo (keep them all together, no subfolder).
2. Either:
   - **GitHub Pages:** repo Settings -> Pages -> deploy from `main` / root.
   - **Netlify:** drag this folder onto app.netlify.com/drop.
3. Open the live URL in Safari -> Share -> **Add to Home Screen**. It opens full-screen
   with its own icon and works offline.

## Files
- index.html, app.js — the app
- manifest.json, sw.js — makes it installable + offline
- icon-180/192/512/1024.png — app icons

To rename it later, change `<title>` and the `apple-mobile-web-app-title` in index.html,
and `name`/`short_name` in manifest.json.
