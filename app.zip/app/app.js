/* Daily — a light, offline tracker. Your data stays on your device. */
(function(){
'use strict';
var KEY='daily_app_v1';
var TABS=['today','goals','tasks','clear'];

/* Keyword -> goal. Typing any of these words counts toward that goal. */
var MAP=[
  {g:'eat', words:['ate clean','clean eating','healthy eating','meal prep','meal prepped','protein','ate well','no junk','salad']},
  {g:'god',  words:['pray','prayed','prayer','church','bible','scripture','worship','devotion']},
  {g:'morning', words:['morning routine','woke early','cold shower','journal','journaled','stretch','stretched','meditate','meditated']},
  {g:'read', words:['read','reading','book','chapter','pages']},
  {g:'dopamine', words:['no pmo','nofap','no porn','sober','stayed clean','clean day','no phone','phone away','locked in','deep work','dopamine detox']},
  {g:'body', words:['gym','lift','lifted','workout','worked out','trained','training','cardio','basketball','hooped','pushups','push ups','pull ups','abs','weights','jog','jogged','went for a run']}
];
var GOALS=[
  {id:'body', icon:'\uD83D\uDCAA', title:'200 lbs, under 10%', sub:'Build the body'},
  {id:'read', icon:'\uD83D\uDCD6', title:'Finish 10 books', sub:'Sharpen the mind'},
  {id:'god',  icon:'\uD83D\uDE4F', title:'Closer to God', sub:'The foundation'},
  {id:'dopamine', icon:'\uD83E\uDDE0', title:'Reset my dopamine', sub:'Discipline over stimulation'},
  {id:'morning', icon:'\u2600\uFE0F', title:'Own my mornings', sub:'Win the day early'},
  {id:'eat', icon:'\uD83E\uDD57', title:'Eat clean', sub:'Fuel the machine'}
];

/* ---- dates (local) ---- */
function pad(n){return (n<10?'0':'')+n;}
function keyOf(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
function dayKey(back){var d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()-back);return keyOf(d);}
function today(){return dayKey(0);}
function parseKey(k){var p=k.split('-');return new Date(+p[0],+p[1]-1,+p[2],12);}
function isKey(k){return typeof k==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(k);}

/* ---- state ---- */
function blank(){return {v:1,days:{},loops:[],tasks:[],updatedAt:0};}
function normalize(s){
  var b=blank();
  if(!s||typeof s!=='object')return b;
  if(s.days&&typeof s.days==='object')Object.keys(s.days).forEach(function(k){
    if(isKey(k)&&Array.isArray(s.days[k]))
      b.days[k]=s.days[k].filter(function(e){return e&&typeof e.t==='string'&&typeof e.id==='string';})
        .map(function(e){return {id:e.id,t:e.t.slice(0,80),g:(typeof e.g==='string'?e.g:'')};});
  });
  if(Array.isArray(s.loops))b.loops=s.loops.filter(function(x){return x&&typeof x.t==='string'&&typeof x.id==='string';})
    .map(function(x){return {id:x.id,t:x.t.slice(0,200),bin:(['open','today','later','letgo'].indexOf(x.bin)>-1?x.bin:'open')};});
  if(Array.isArray(s.tasks))b.tasks=s.tasks.filter(function(x){return x&&typeof x.t==='string'&&typeof x.id==='string';})
    .map(function(x){return {id:x.id,t:x.t.slice(0,200)};});
  b.updatedAt=typeof s.updatedAt==='number'?s.updatedAt:0;
  return b;
}
var S; try{S=normalize(JSON.parse(localStorage.getItem(KEY)));}catch(e){S=blank();}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(S));}catch(e){}}
function save(){S.updatedAt=Date.now();persist();scheduleSync();}

/* ---- optional cloud sync (same data across devices if hosted with it) ---- */
var docRef=null,syncT=null,pushing=false,again=false;
function scheduleSync(){if(!docRef)return;clearTimeout(syncT);syncT=setTimeout(push,900);}
function push(){if(!docRef)return;if(pushing){again=true;return;}pushing=true;
  docRef.set({json:JSON.stringify(S),updatedAt:S.updatedAt}).catch(function(){}).then(function(){pushing=false;if(again){again=false;push();}});}
function initSync(){try{
  if(!window.claude||typeof window.claude.use!=='function')return;
  Promise.all([window.claude.use('db'),window.claude.use('user')]).then(function(r){
    var db=r[0],user=r[1];if(!db||!user)return null;
    return user.id().then(function(uid){if(!uid)return null;
      var ref=db.doc('data/users/'+uid+'/daily');
      return ref.get().then(function(snap){
        var localNewer=true;
        if(snap&&snap.exists){var body=snap.data()||{},rem=null;try{rem=normalize(JSON.parse(body.json));}catch(e){}
          if(rem&&rem.updatedAt>S.updatedAt){S=rem;persist();renderAll();localNewer=false;}
          else if(rem&&rem.updatedAt===S.updatedAt)localNewer=false;}
        docRef=ref;if(localNewer&&S.updatedAt>0)push();
      });
    });
  }).catch(function(){});
}catch(e){}}

/* ---- helpers ---- */
function $(id){return document.getElementById(id);}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function rid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7);}
function nice(k,o){return parseKey(k).toLocaleDateString('en-US',o||{weekday:'long',month:'long',day:'numeric'});}
function esc4re(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function matchGoal(text){
  var low=text.toLowerCase();
  for(var i=0;i<MAP.length;i++)for(var j=0;j<MAP[i].words.length;j++){
    var w=MAP[i].words[j];
    var re=new RegExp('(^|[^a-z])'+esc4re(w)+'([^a-z]|$)');
    if(re.test(low))return MAP[i].g;
  }
  return '';
}
function goalIcon(g){for(var i=0;i<GOALS.length;i++)if(GOALS[i].id===g)return GOALS[i].icon;return '\u2713';}

var viewBack=0;

/* ---- render: Today ---- */
function renderToday(){
  var k=dayKey(viewBack);
  $('date').textContent=viewBack===0?'Today':nice(k,{weekday:'long',month:'short',day:'numeric'});
  $('hi').textContent=viewBack===0?nice(k):'Looking back';
  $('nextBtn').disabled=viewBack===0;
  $('dayLabel').textContent=viewBack===0?'':nice(k,{month:'short',day:'numeric'});
  var list=S.days[k]||[];
  $('logEmpty').style.display=list.length?'none':'block';
  $('pills').innerHTML=list.map(function(e){
    return '<span class="pill'+(e.g?' match':'')+'"><span class="ic">'+(e.g?goalIcon(e.g):'\u2713')+'</span>'+esc(e.t)+'<button class="x" data-act="unlog" data-id="'+e.id+'" aria-label="Remove">\u00D7</button></span>';
  }).join('');
}

/* ---- render: Goals ---- */
function goalStats(id){
  var days=0,total=0,streak=0,todayHit=false,cur=0,broke=false;
  Object.keys(S.days).forEach(function(k){var hit=S.days[k].some(function(e){return e.g===id;});if(hit){days++;total++;}});
  for(var i=0;i<120;i++){var k=dayKey(i);var hit=(S.days[k]||[]).some(function(e){return e.g===id;});
    if(i===0)todayHit=hit;
    if(hit&&!broke)cur++;else if(i>0||!hit){if(!hit&&i===0){}else if(!hit){broke=true;}}
  }
  // simpler streak: consecutive days back from today (or yesterday if today empty)
  streak=0;var start=todayHit?0:1;for(var j=start;j<120;j++){if((S.days[dayKey(j)]||[]).some(function(e){return e.g===id;}))streak++;else break;}
  return {days:days,streak:streak,todayHit:todayHit};
}
function renderGoals(){
  $('goalsCard').innerHTML=GOALS.map(function(g){
    var st=goalStats(g.id);
    var pct=Math.min(100,Math.round(st.streak/14*100));
    var sub = st.streak>0 ? st.streak+(st.streak===1?' day':' days')+' going' : (st.days>0? 'last done a while ago':'not started yet');
    var ring='<div class="ring"><svg width="54" height="54"><circle cx="27" cy="27" r="23" fill="none" stroke="#f4e7e2" stroke-width="6"/>'+
      '<circle cx="27" cy="27" r="23" fill="none" stroke="'+(st.todayHit?'#ff8f3f':'#ff6a53')+'" stroke-width="6" stroke-linecap="round" stroke-dasharray="'+(2*Math.PI*23)+'" stroke-dashoffset="'+(2*Math.PI*23*(1-pct/100))+'"/></svg>'+
      '<span class="pct">'+g.icon+'</span></div>';
    return '<div class="goal">'+ring+'<div style="flex:1"><div class="gt">'+esc(g.title)+'</div><div class="gs">'+esc(g.sub)+' \u00B7 '+sub+'</div></div>'+
      (st.todayHit?'<div class="chk on">\u2713</div>':'')+'</div>';
  }).join('');
}

/* ---- render: Clear ---- */
function renderClear(){
  var open=S.loops.filter(function(x){return x.bin==='open';});
  var html='';
  if(open.length)html+=open.map(function(x){
    return '<div class="loop"><span class="lt">'+esc(x.t)+'</span>'+
      '<button class="act" data-act="lmove" data-bin="today" data-id="'+x.id+'">Today</button>'+
      '<button class="act" data-act="lmove" data-bin="letgo" data-id="'+x.id+'">Let go</button>'+
      '<button class="del" data-act="ldel" data-id="'+x.id+'" aria-label="Delete">\u00D7</button></div>';
  }).join('');
  var td=S.loops.filter(function(x){return x.bin==='today';});
  if(td.length){html+='<div style="font-size:13px;font-weight:700;color:var(--sub);text-transform:uppercase;letter-spacing:.06em;margin:16px 0 6px">Today</div>';
    html+=td.map(function(x){return '<div class="loop"><span class="lt">'+esc(x.t)+'</span><button class="del" data-act="ldel" data-id="'+x.id+'">\u2713</button></div>';}).join('');}
  var lg=S.loops.filter(function(x){return x.bin==='letgo';});
  if(lg.length){html+='<div style="font-size:13px;font-weight:700;color:var(--sub);text-transform:uppercase;letter-spacing:.06em;margin:16px 0 6px">Let go</div>';
    html+=lg.map(function(x){return '<div class="loop"><span class="lt" style="color:var(--sub)">'+esc(x.t)+'</span><button class="del" data-act="ldel" data-id="'+x.id+'">\u00D7</button></div>';}).join('');}
  $('loops').innerHTML=html;
}

/* ---- render: Tasks ---- */
function renderTasks(){
  var n=S.tasks.length;
  $('taskCount').textContent=n?(n+(n===1?' thing left':' things left')):'';
  $('taskEmpty').style.display=n?'none':'block';
  $('tasks').innerHTML=S.tasks.map(function(x){
    return '<div class="task" id="tk-'+x.id+'"><button class="box" data-act="check" data-id="'+x.id+'" aria-label="Check off">\u2713</button>'+
      '<span class="tt">'+esc(x.t)+'</span><button class="del" data-act="tdel" data-id="'+x.id+'" aria-label="Delete">\u00D7</button></div>';
  }).join('');
}
var lastDone=null,toastT=null;
function toast(msg){$('toastMsg').textContent=msg;$('toast').classList.add('on');clearTimeout(toastT);toastT=setTimeout(function(){$('toast').classList.remove('on');lastDone=null;},4000);}
function removeTask(id,msg){
  var idx=-1;for(var i=0;i<S.tasks.length;i++)if(S.tasks[i].id===id){idx=i;break;}
  if(idx<0)return;
  var row=$('tk-'+id);
  lastDone={task:S.tasks[idx],idx:idx};
  S.tasks.splice(idx,1);save();toast(msg);
  if(row&&msg==='Done'){row.classList.add('done');setTimeout(function(){row.classList.add('gone');},260);setTimeout(renderTasks,560);}
  else renderTasks();
}

function renderAll(){[renderToday,renderGoals,renderTasks,renderClear].forEach(function(f){try{f();}catch(e){if(window.console)console.error(e);}});}

/* ---- breathing ---- */
var bTimer=null;
function stopBreath(done){clearInterval(bTimer);bTimer=null;$('bc').style.transform='scale(.62)';$('bp').textContent=done?'Done':'Breathe';
  $('bsub').textContent=done?'Nice. Carry that calm with you.':'One minute. In four, hold four, out four, hold four.';$('bbtn').textContent=done?'Again':'Start';}
function startBreath(){var PH=[['In','scale(1)'],['Hold','scale(1)'],['Out','scale(.62)'],['Hold','scale(.62)']];var t=0;$('bbtn').textContent='Stop';
  function tick(){if(t>=64){stopBreath(true);return;}var p=Math.floor(t/4)%4,sec=4-(t%4),round=Math.floor(t/16)+1;
    if(t%4===0)$('bc').style.transform=PH[p][1];$('bp').textContent=PH[p][0];$('bsub').textContent=sec+' \u00B7 round '+round+' of 4';t++;}
  tick();bTimer=setInterval(tick,1000);}

/* ---- navigation ---- */
function go(tab){if(TABS.indexOf(tab)<0)tab='today';
  TABS.forEach(function(n){$('t-'+n).classList.toggle('on',n===tab);});
  Array.prototype.forEach.call(document.querySelectorAll('nav button'),function(b){b.classList.toggle('on',b.getAttribute('data-tab')===tab);});
  renderAll();try{window.scrollTo(0,0);}catch(e){}}

/* ---- actions ---- */
document.addEventListener('click',function(e){
  var el=e.target.closest?e.target.closest('[data-act]'):null;if(!el)return;
  var act=el.getAttribute('data-act'),id=el.getAttribute('data-id');
  try{switch(act){
    case 'go':go(el.getAttribute('data-tab'));return;
    case 'prev':if(viewBack<120){viewBack++;renderToday();}return;
    case 'next':if(viewBack>0){viewBack--;renderToday();}return;
    case 'log':{
      var raw=$('logIn').value;
      var parts=raw.split(/[,\n]|\band\b/).map(function(s){return s.replace(/\s+/g,' ').trim();}).filter(Boolean);
      if(!parts.length)return;
      var k=dayKey(viewBack);if(!S.days[k])S.days[k]=[];
      parts.forEach(function(p){S.days[k].push({id:rid(),t:p.slice(0,80),g:matchGoal(p)});});
      $('logIn').value='';save();renderAll();return;
    }
    case 'unlog':{var k=dayKey(viewBack);if(S.days[k]){S.days[k]=S.days[k].filter(function(x){return x.id!==id;});if(!S.days[k].length)delete S.days[k];save();renderAll();}return;}
    case 'dump':{
      var lines=$('dumpIn').value.split('\n').map(function(s){return s.trim();}).filter(Boolean);
      if(!lines.length)return;
      lines.forEach(function(l){S.loops.push({id:rid(),t:l.slice(0,200),bin:'open'});});
      $('dumpIn').value='';save();renderClear();return;
    }
    case 'lmove':{var x=S.loops.filter(function(y){return y.id===id;})[0];if(x){x.bin=el.getAttribute('data-bin');save();renderClear();}return;}
    case 'addtasks':{
      var tl=$('taskIn').value.split('\n').map(function(s){return s.replace(/^[-*\u2022\s]+/,'').trim();}).filter(Boolean);
      if(!tl.length)return;
      tl.forEach(function(t){S.tasks.push({id:rid(),t:t.slice(0,200)});});
      $('taskIn').value='';save();renderTasks();return;
    }
    case 'check':removeTask(id,'Done');return;
    case 'tdel':removeTask(id,'Deleted');return;
    case 'undo':if(lastDone){S.tasks.splice(Math.min(lastDone.idx,S.tasks.length),0,lastDone.task);lastDone=null;save();renderTasks();}
      $('toast').classList.remove('on');return;
    case 'ldel':S.loops=S.loops.filter(function(y){return y.id!==id;});save();renderClear();return;
    case 'breath':if(bTimer)stopBreath(false);else startBreath();return;
  }}catch(err){if(window.console)console.error(err);}
});

/* roll to new day */
var lastDay=today();
function checkDay(){var t=today();if(t!==lastDay){lastDay=t;viewBack=0;}renderAll();}
document.addEventListener('visibilitychange',function(){if(!document.hidden)checkDay();});
window.addEventListener('pageshow',checkDay);
setInterval(function(){if(today()!==lastDay)checkDay();},20000);

/* register offline service worker when hosted (not inside claude) */
try{if('serviceWorker' in navigator && location.protocol==='https:' && !/claude\.(ai|site|com)$/.test(location.hostname) && window.top===window.self)
  navigator.serviceWorker.register('sw.js').catch(function(){});}catch(e){}

go('today');
initSync();
})();
